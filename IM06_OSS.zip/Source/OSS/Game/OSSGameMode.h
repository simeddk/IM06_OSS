#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "OSSGameMode.generated.h"

UCLASS(minimalapi)
class AOSSGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	AOSSGameMode();
};



